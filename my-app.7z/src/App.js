import React from 'react';
import Header from './componenets/Header';
import Feed from './componenets/Feed';
function App() {
  return (
<div className="App">
  <Header/>
  <Feed/>
</div>
  );
}

export default App;
